URICOFF — PREMIUM CUSTOMER TESTIMONIAL

Final video: URICOFF-testimonial-premium-9x16-1080x1920.mp4
37.07 seconds | 1080x1920 | 9:16 | 30fps | H.264/AAC
The MP4 is supplied separately from this document bundle.

A — Full timestamped source transcript, 11:15.233, in Markdown/TXT/JSON.
    Uncertain source phrases are marked and require manual confirmation.
    A 100% verified verbatim transcript is not claimed.
B — Final edited video's Malay SRT, URICOFF-subtitles.srt.
C — Scene-by-scene editing timeline, Markdown/CSV.
D — Motion graphics, transition and SFX cue sheet, Markdown/JSON.
E — Final MP4 supplied separately.
F — CTA/cover recommendations and portrait JPEG cover.

EXTRAS: edit-project.json, QC report, original music/SFX stems, credits and font licence.
The 1GB original recording and model files are not redistributed in this bundle.

The actual customer and source voice are retained. No new testimonial, rating,
verified badge, fabricated product label or medical-result footage is added.
The customer's own continued dietary-control statement is retained.
Background score is composed/synthesized for this project, not an external stock track.
