# Editing timeline — URICOFF testimonial

Final: 37.07s, 1080 × 1920, 9:16, 30 fps.

| Final | Source | Scene | Visual / editorial purpose |
|---|---|---|---|
| 0.00–2.80s | 647.14–649.94s | hook-bonus | Hook autentik |
| 2.80–8.23s | 18.56–24.00s | latar-pengalaman | Latar pengalaman |
| 8.23–16.20s | 87.70–95.68s | kesukaran-dulu | Kesukaran yang diceritakan |
| 16.20–20.83s | 24.00–28.62s | jumpa-produk | Kenali produk yang dicuba |
| 20.83–23.43s | 38.10–40.70s | pengalaman-sendiri | Kata pelanggan, untuk dirinya |
| 23.43–30.23s | 158.00–164.80s | pemakanan | Konteks pemakanan dikekalkan |
| 30.23–31.77s | 660.06–661.60s | jujur | Penutup peribadi |
| 31.77–33.47s | 663.16–664.86s | ikhlas | Penutup peribadi |
| 33.47–37.07s | Actual product frame at 615s; no new voice | brand-cta | Brand closing dan CTA |

Customer face, voice and setting are retained. The history includes his own “20…25 years” correction. His continued dietary control is retained. The uncertain sentence between the two closing excerpts is omitted. No medical-result visuals, unverified rating or new efficacy claim is added.
