# Motion graphics, transition and SFX cue sheet

| Time | Type | Cue |
|---|---|---|
| 0.000s | Motion | hook-bonus: restrained push-in 105–109%; Montserrat phrase captions with 100–103–100% micro-scale |
| 0.030s | SFX | impact |
| 0.080s | Motion | Kinetic headline “Satu bonus bagi saya”: 12px slide-up and 140ms fade; 68px Montserrat Bold |
| 0.220s | Motion | Champagne underline reveals left-to-right over 380ms with easing |
| 2.800s | Motion | latar-pengalaman: restrained push-in 105–108%; Montserrat phrase captions with 100–103–100% micro-scale |
| 2.800s | Motion | Lower third “Pengalaman Pelanggan”; thin line and slide-up; no customer name |
| 2.860s | SFX | click |
| 8.233s | Motion | kesukaran-dulu: restrained push-in 106–110%; Montserrat phrase captions with 100–103–100% micro-scale |
| 16.200s | Motion | jumpa-produk: restrained push-in 100–102%; Montserrat phrase captions with 100–103–100% micro-scale |
| 16.200s | Transition | 0.20-second dissolve; actual packaging photo maintains aspect ratio |
| 16.220s | SFX | air |
| 16.280s | Motion | Product title URICOFF and Grow Health typography; actual carton photo has slow pan and 4px float |
| 20.833s | Motion | pengalaman-sendiri: restrained push-in 106–110%; Montserrat phrase captions with 100–103–100% micro-scale |
| 20.833s | Transition | 0.20-second dissolve from product insert back to the original customer |
| 20.893s | Motion | Attributed quote “Bagi saya ni” appears above the original customer |
| 23.433s | Motion | pemakanan: restrained push-in 105–108%; Montserrat phrase captions with 100–103–100% micro-scale |
| 23.433s | Motion | Context label “Pemakanan tetap dijaga” and animated underline |
| 23.493s | SFX | click |
| 30.233s | Motion | jujur: restrained push-in 105–107%; Montserrat phrase captions with 100–103–100% micro-scale |
| 31.767s | Motion | ikhlas: restrained push-in 110–112%; Montserrat phrase captions with 100–103–100% micro-scale |
| 31.817s | Motion | Attributed closing quote “Betul-betul ikhlas” with slide-up/fade |
| 31.827s | SFX | click |
| 33.467s | Motion | brand-cta: restrained push-in 100–102%; Montserrat phrase captions with 100–103–100% micro-scale |
| 33.467s | Transition | 0.20-second dissolve; actual packaging photo maintains aspect ratio |
| 33.487s | SFX | air |
| 33.527s | Motion | Cream brand closing: “Kenali produk ini” and packaging description |
| 33.627s | Motion | CTA outline reveals with subtle upward motion |
| 33.667s | Motion | CTA “Lihat Maklumat Produk”, 38px Montserrat; arrow slides 9px to the right |
| 33.717s | SFX | shimmer |
