# Motion graphics, transition and SFX cue sheet

| Time | Type | Cue |
|---|---|---|
| 0.000s | Motion | hook-bonus: restrained push-in 105–109%; Montserrat phrase captions with 100–103–100% micro-scale |
| 0.030s | SFX | impact |
| 2.800s | Motion | latar-pengalaman: restrained push-in 105–108%; Montserrat phrase captions with 100–103–100% micro-scale |
| 2.860s | SFX | click |
| 8.233s | Motion | kesukaran-dulu: restrained push-in 106–110%; Montserrat phrase captions with 100–103–100% micro-scale |
| 16.200s | Motion | jumpa-produk: restrained push-in 100–102%; Montserrat phrase captions with 100–103–100% micro-scale |
| 16.200s | Transition | 0.20-second dissolve; actual packaging photo maintains aspect ratio |
| 16.220s | SFX | air |
| 20.833s | Motion | pengalaman-sendiri: restrained push-in 106–110%; Montserrat phrase captions with 100–103–100% micro-scale |
| 20.833s | Transition | 0.20-second dissolve from product insert back to the original customer |
| 23.433s | Motion | pemakanan: restrained push-in 105–108%; Montserrat phrase captions with 100–103–100% micro-scale |
| 23.493s | SFX | click |
| 30.233s | Motion | jujur: restrained push-in 105–107%; Montserrat phrase captions with 100–103–100% micro-scale |
| 31.767s | Motion | ikhlas: restrained push-in 110–112%; Montserrat phrase captions with 100–103–100% micro-scale |
| 31.827s | SFX | click |
| 33.467s | Motion | brand-cta: restrained push-in 100–102%; Montserrat phrase captions with 100–103–100% micro-scale |
| 33.467s | Transition | 0.20-second dissolve; actual packaging photo maintains aspect ratio |
| 33.487s | SFX | air |
| 33.717s | SFX | shimmer |
