# Cinematic Storytelling — CTA dan thumbnail cover

CTA dipilih, mengikut arahan pengguna: **Tekan beg Kuning**. CTA ialah copy jenama, bukan dialog baharu pelanggan.

Butang botanical charcoal, ikon beg champagne yellow dan anak panah ke bawah. Tiada ayat mendesak atau janji kesembuhan ditambah.

Cover: **“Satu bonus bagi saya.”** — petikan yang benar-benar disebut pada 10:47–10:49. Potret pelanggan asal, wordmark URICOFF, cream white dan champagne gold; tiada bintang atau badge verified. Cover JPEG dieksport daripada frame hook video akhir.

Tagline/deskripsi: **Serbuk minuman berperisa lemon**, berdasarkan teks pada gambar packaging yang diberikan. B-roll bergerak dan imej packaging sebenar daripada footage mengekalkan logo, warna dan reka bentuknya.
