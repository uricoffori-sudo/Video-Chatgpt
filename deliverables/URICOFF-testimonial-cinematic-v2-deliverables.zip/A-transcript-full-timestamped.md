# A. Transkrip penuh bertimestamp — URICOFF

Sumber 11:15.233. Liputan dari awal hingga akhir rakaman. Dua pass transkripsi penuh (audio asal dan audio dikurangkan bunyi) dibandingkan dengan pass tambahan pada petikan pilihan.

**Status ketepatan:** ini transkripsi berbantu ASR yang disemak untuk penyuntingan, bukan dakwaan verifikasi manusia 100% perkataan. Frasa yang belum dapat dipastikan ditandakan `[kurang jelas]` dan tidak diteka. Oleh itu fail ini tidak patut dipersembahkan sebagai verbatim yang telah disahkan 100%. Ejaan URICOFF disahkan pada packaging. Ejaan nama pelanggan belum disahkan dan tidak digunakan dalam grafik. Punctuation/ejaan biasa diperjelas; filler, pembetulan angka “20…25 tahun”, dan konteks pemakanan dikekalkan.

Masa di bawah merujuk **video asal**, bukan video akhir. Pertanyaan penemubual dan jawapan pelanggan dikekalkan dalam urutan rakaman. Pernyataan perubatan di sini ialah dialog sumber, bukan maklumat baharu yang ditambah oleh editor. Video akhir menggunakan petikan terpilih dan tidak memasukkan frasa yang belum jelas, bacaan makmal, cadangan dos atau jaminan masa keberkesanan.

**00:00:00.000 – 00:00:24.000**

Okey, saya Norani bin Jafar [ejaan nama belum disahkan]. Nama ni unik sikitlah. Okey, saya berumur 65 tahun. Boleh tak kongsikan, dah berapa lama [kata panggilan kurang jelas] ada masalah gout? Okey, kalau ikutkan gout ni, saya dah mengalami gout yang lebih kurang 20 tahun lebihlah, 25 tahun lebih.



**00:00:24.000 – 00:00:48.000**

Tapi yang nak jadikan cerita, bila saya berjumpa dengan URICOFF ni, [frasa kurang jelas] bila saya makan udang, [frasa kurang jelas] tak boleh jalan. Bila saya tengok dalam... dalam TikTok, ada dia perkenalkan URICOFF ni. Saya pun cuba URICOFF nilah. Alhamdulillah, memang betul-betul berkesan bagi saya ni. Alhamdulillahlah, bila saya berjumpa dengan URICOFF ni, saya rasa satu... membantulah, daripada... pada saya, kan, untuk...



**00:00:48.000 – 00:01:12.000**

...sakit-sakit ni dengan gout ni. Alhamdulillah. Sebelum jumpa URICOFF tu, kenapa tak ikhtiar dengan cara lain ataupun dengan produk lain? Saya cakap tentang gout ni, saya [frasa kurang jelas] macam-macam cara, dengan herba, dengan painkiller. Macam-macam, apa orang cerita semua saya ikut. Tapi tak ada satu yang berkesan, kan. Ada, cuma yang memang kita kata painkiller tu, dia legalah sementara, kan.



**00:01:12.000 – 00:01:36.000**

Tapi bila dapat URICOFF ni, alhamdulillah, memang... memang betul-betul berkesanlah bagi saya. Dulu masa kena serangan gout yang teruk, bagaimana dengan keadaan nak solat, keadaan nak buat kerja tu macam mana? Okey, dia bila saya kena serangan gout yang teruk ni, sampai saya nak buka baju pun memang tak bolehlah. Kena bantuan daripada orang rumahlah, kan.



**00:01:36.000 – 00:02:00.000**

Nak angkat tangan, nak berjalan memang tak bolehlah. Kena duduk atas ni, kerusi rodalah. Kerusi roda. Dan [frasa kurang jelas] nak pergi masjid Jumaat pun tak mampu, kan. Memang tak boleh nak pergi. Tapi itulah, bila dah ada URICOFF ni, alhamdulillah, memang kita... alhamdulillahlah. Tak ada masalah. Kita tak risaulah. [Frasa kurang jelas.] Agak-agak dah berapa lama...



**00:02:00.000 – 00:02:24.000**

...Haji gunakan URICOFF ni? [Pertanyaan pendek kurang jelas.] Dah berapa lama? Mula... 2022. Saya rasa saya start 2022. [Sebutan tahun berikutnya kurang jelas.] Kotak yang mula-mula. Kotak mula-mula tu. Sama tulah. Biasanya apa makanan yang Haji makan je...



**00:02:24.000 – 00:02:48.000**

...terus kena serangan gout? Saya ni, sebenarnya saya peminat daging, kan. Daging [jenis/frasa kurang jelas] ni memang saya... memang tak boleh tinggalkan. Memang pantang-pantang jumpa, kan. Memang saya minat tulah. Lepas tu yang lain-lain tu macam udang, macam sotong, ketam, memang. Seafood ni memang favourite sayalah. Tapi bila dah kena ni, walaupun ada URICOFF, saya pun cuba kurangkanlah. Kita [satu perkataan kurang jelas] risiko dia benda ni, kan. Kalau kita ambil juga...



**00:02:48.000 – 00:03:12.000**

...mungkin dah payah kita nak kontrollah, kan. Walaupun kita tak ada URICOFF sekalipun, tapi saya kontrol jugalah, pengawalan jugalah. [Kata penyambung kurang jelas.] Mula-mula apa yang membuatkan Haji rasa yakin nak cuba URICOFF? Okey, itulah. Saya cakap terus, saya makan udang, memang saya makan banyak semua. Saya tak boleh berjalan. Pagi-pagi memang saya tak boleh. Nak bengkok lutut, tak mampu.



**00:03:12.000 – 00:03:36.000**

Memang saya tak boleh nak berjalan langsunglah. Lepas tu saya duduk di dalam bilik [frasa kurang jelas] tengok tu dengan TikTok. Nampak ni, URICOFF ni. Bila nampak URICOFF ni, saya pun tengoklah. Tengok-tengok daripada syarikat [frasa kurang jelas], dengan garanti dia. Dia kata kalau tak [frasa kurang jelas] sembuh, dia pulangkan balik, dia akan bagi duit. Saya kata hebat ni, kan. Saya pun cubalah. Bila cubalah, betul...



**00:03:36.000 – 00:04:00.000**

...apa yang dia kata dua jam tu memang betul. Memang tak... [frasa kurang jelas]. Bukan dia saja yang cakap. Memang betullah. Itu saya yakin dengan URICOFF. Boleh cakap tak macam mana mula-mula ambil hari-hari, lepas tu sekarang macam mana pula? Dia dulu ni, masa mula-mula kena, saya ambil [frasa kurang jelas]. Saya tengok di kotaklah, kan. Dia suggest kalau kita dah sembuh, stoplah, kan. Masa mula-mula tu mungkin yang mula-mula saya ambil...



**00:04:00.000 – 00:04:24.000**

...hari ni sehari, esok sehari, dan dah satu sachet tu, dah sembuh saya tinggallah. Bila sakit pula, mungkin dalam tiga, empat hari saya sakit, saya ambil satu sachet balik, kan. Kadang-kadang dulu ni saya guna separuh. Kalau tak berkesan, saya ambil satulah, kan. Sebab [frasa kurang jelas] saya sendiri kontrollah benda tu, kan. Tapi alhamdulillah, memang tak ada masalah. Boleh ke kongsikan sebenarnya sakit gout tu rasa dia macam mana?



**00:04:24.000 – 00:04:48.000**

Oh, siapa yang kena sakit gout ni, memang bagi sayalah, siapa yang tak biasa kena mungkin tak tahulah. Sakit gout ni, dia satu sakit... kadang-kadang ni dia rasa macam jarum. Dia cucuk di tempat yang sakit. [Frasa kurang jelas.] Tapi sebenarnya gout dia kena saraf...



**00:04:48.000 – 00:05:12.000**

...sakit ni sampai kita nak bergerak pun takut, kan. Sentuh ni lagi-lagilah. Orang dah sentuh, memang tak bolehlah, kan. Sakit, memang sakit. Terus saya kata orang yang kena gout ni, dia akan tahu sakit dia yang mana, dan yang mana tak kena ni, dia tak tahulah, kan. Memang sakit, memang sakit serangan gout ni. Kalau macam pengalaman buruk yang Haji tak boleh lupa masa serangan gout, ada tak? Saya pengalaman buruk...



**00:05:12.000 – 00:05:36.000**

...itulah, saya tak mampu berjalanlah. Saya duduk dengan isteri saya. Nak masuk wheelchair pun tak boleh, kan. Nak angkat [frasa kurang jelas] badan saya besar, kan. Bila nak angkat [frasa kurang jelas] tak boleh. Jadi satu masalahlah. Nak pergi mandi pun susah. Yang tu, yang pengalaman saya rasa paling saya takut, yang tulah. Betul beringat, cukup beringatlah, kan. Sebelum jumpa URICOFF ni, apa ikhtiar yang Haji...



**00:05:36.000 – 00:06:00.000**

...itulah, saya... jumpa URICOFF ni, macam-macamlah. Kadang-kadang kawan-kawan dia recommend kata buat herba nilah, goreng biji betiklah. Dia bagi apa ni, minyak sapulah, macam-macam, kan. Ada macam-macam herba yang dia bagi. Apa yang dia bercerita, semua saya cuba. Cuba minum apa tu, apa, daun sup, semua buat dengan blender dengan tu, kan.



**00:06:00.000 – 00:06:24.000**

Tak berkesan, kan. Tak, tak, memang tak berkesan. Okey, macam Haji dah gunakan URICOFF, dah pernah ikhtiar macam-macam, jadi apa perbezaan yang Haji boleh kongsikan antara produk yang lain tu dengan URICOFF ni? Saya rasa nilah. Kalau kita tengok URICOFF ni, kalau kita tengok dari segi dia punya ni, bukan [frasa kurang jelas] bahan kimia, kan. Dia sebenarnya kalau kita tengok sini...



**00:06:24.000 – 00:06:48.000**

...banyak daripada ekstrak tumbuh-tumbuhan, kan. Maknanya kata kita tak risaulah kita nak makan, kan. Manakala kalau kita makan dari segi painkiller ni, mungkin efek pada buah pinggang. [Frasa kurang jelas.] Tapi dari segi URICOFF ni saya rasa tak risau sangatlah. Kita makan pun, kita minum pun, kita rasa macam bau limau, macam itulah, kan. Saya confidentlah. Okey, selama...



**00:06:48.000 – 00:07:12.000**

...Haji gunakan, ada tak macam rasa kesan-kesan yang tak baik pada badan Haji? Saya rasa setakat ni tak ada rasa efek tu. Tak ada rasa apa-apalah. [Frasa kurang jelas.] Apa-apa yang lenguh sana, lenguh, sakit-sakit, tak rasalah, kan. Cuma orang kata mungkin dari segi efikasi itu lambat sikit, tu adalah, kan. Yang tulah, mungkin lama saya dah ambil dia, kan. Itulah, efikasi itu lambat sikit.



**00:07:12.000 – 00:07:36.000**

Sikitlah, kalau dulu kata dua jam, mungkin hari ni lebih sikitlah. Itulah. Kalau macam yang lambat tu, berapa lambat yang dulu? Okey, dulu ni mula-mula saya ambilnya, dia kata dalam satu jam setengah, dua jam tu memang dalam lingkungan tu, memang okeylah. Tapi hari ni kadang-kadang dalam masa tiga jam tu baru dia [frasa kurang jelas], baru dia dah nampak, kan. Tapi...



**00:07:36.000 – 00:08:00.000**

...tak apalah kalau cuma tiga jam pun dia sembuh. Alhamdulillahlah. Sebelum gunakan URICOFF, pernah tak Haji check asid urik? Bacaan itu berapa? Pernah. Sebelum ni, saya bacaan saya 700. 700. Kan, border dia dalam 300, 400 tu, kan. Lepas tu bila saya ambil URICOFF ni, bacaan dia... [angka/ayat tidak jelas; tidak diteka].



**00:08:00.000 – 00:08:24.000**

[Sebutan angka/tarikh pada awal bahagian ini tidak jelas.] Bulan ni saya akan check balik, nak tengok macam mana, kan. Nanti saya pergi check baliklah. Okey, bagi pandangan Haji sendiri, secara jujurnya, adakah harga yang kami jual ni berbaloi dengan dia punya kesan? Dari segi harga ni, bagi saya kalau benda tu berkesan, contohnya URICOFF ni...



**00:08:24.000 – 00:08:48.000**

...dia berkesan. Gout ni bukan mudah untuk... pengawalan gout ni bukan mudah. Bermacam-macam cara orang buat [frasa kurang jelas]. Tapi dari segi harga ni, okeylah, berpatutanlah. Bolehlah, mampu. Kita mampu belilah. Gout ni, kita boleh tahu ke bila dia nak datang? Macam ada ciri-ciri awal yang kata, oh, dia nak kena gout ni, ada tak?



**00:08:48.000 – 00:09:12.000**

Gout ni, orang yang biasa kena, macam saya dah lama, ada dua puluh tahun lebihlah. Dia ada simptom dia. Contoh, dia akan kita rasa, contoh, jari, kan. Contoh jari saya ni. Bila saya genggam macam ni, dia tak dapat, dia rasa sakit sikitlah. Dah, nampaklah. Ni simptom dia nak mari. Ni, dia rasa ni. Dia rasalah. Lagi satu, kaki. Kaki ni kita akan rasa di buku lali ataupun...



**00:09:12.000 – 00:09:36.000**

...di dekat dengan hujung ibu jari kaki tu, kan, ada rasa macam sakit-sakit. Dia mainlah. Cepat-cepat kita ambil ni, insya-Allah memang tak kena. Apa perasaan Haji bila dah okey daripada gout sampai sekarang? Alhamdulillah. Memang [satu perkataan kurang jelas], terima kasih kepada Allah Taala, bertemu dengan [frasa kurang jelas].



**00:09:36.000 – 00:10:00.000**

Lama sangat, ada 20 tahun lebih. Nak cari dapat benda yang boleh kawal gout ni memang tak ada. Setakat ni apa yang mereka recommend ubat ni, bagi saya tak ada kesan. Tak ada. Bukan kita nak compare dengan yang lain-lain. Tak, tak [frasa kurang jelas] sebut-sebut nama orang, tapi memang tak kesan. Cuma URICOFF ni sahaja yang bagi saya nampak betul-betul kesan.



**00:10:00.000 – 00:10:24.000**

Boleh tak Haji sarankanlah dekat orang kat luar sana, ada masalah gout juga tapi masih ragu-ragu nak cuba? Haji sendiri kan dah cuba. Assalamualaikum semua, kawan-kawan semua yang mana di luar sana, yang mana [perkataan kurang jelas] menghidapi gout ni, saya rasa jangan ragu-ragu untuk menggunakan URICOFF ni. Satu benda, satu ubat yang baik untuk pencegahan...



**00:10:24.000 – 00:10:48.000**

...untuk menyembuhkan gout ni. Dan jangan takut dari segi harga ni, walaupun kita rasa sedikit tinggi, tapi kalau boleh menyembuhkan daripada kita menahan sakit ni, lebih baik kita guna URICOFF nilah. Saya rasa URICOFF ni satu... apa, ubat yang cukup baiklah bagi saya, kerana saya telah mengalami lebih 20 tahun lebih gout ni. Dan alhamdulillah, hari ni saya dah dapat ni. Saya rasa...



**00:10:48.000 – 00:11:12.000**

...satu bonus bagi sayalah untuk gout ni. Okey, adakah temu bual kita hari ni adalah jujur daripada pengalaman Haji sendiri ataupun sekadar lakonan sahaja? Ya, jujur. Memang jujur. Tak ada [frasa kurang jelas] dengan benda ni. Benda yang betul-betul ikhlas, kan. Sebab kalau kita [frasa kurang jelas], tanya Encik Zul, kan, kita ada order berapa banyak, kan. Tak pernah miss. Tiap-tiap bulan [frasa kurang jelas].



**00:11:12.000 – 00:11:15.233**

[Dialog akhir tentang “stok” kurang jelas; tiada ayat penuh disahkan.]


