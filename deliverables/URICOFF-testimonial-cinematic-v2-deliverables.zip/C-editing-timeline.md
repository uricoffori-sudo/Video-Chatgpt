# Editing timeline — Cinematic Storytelling V2

Final: 37.87s, 1080 × 1920, 9:16, 30 fps.

| Final | Source | Scene | Visual / editorial purpose |
|---|---|---|---|
| 0.00–2.80s | 647.14–649.94s | hook-bonus | Hook autentik |
| 2.80–8.23s | 18.56–24.00s | latar-pengalaman | Latar pengalaman |
| 8.23–16.20s | 87.70–95.68s | kesukaran-dulu | Kesukaran yang diceritakan |
| 16.20–20.83s | 24.00–28.62s | jumpa-produk | B-roll bergerak daripada rakaman produk sebenar |
| 20.83–23.43s | 38.10–40.70s | pengalaman-sendiri | Kata pelanggan, untuk dirinya |
| 23.43–30.23s | 158.00–164.80s | pemakanan | Konteks pemakanan dikekalkan |
| 30.23–31.77s | 660.06–661.60s | jujur | Penutup peribadi |
| 31.77–33.47s | 663.16–664.86s | ikhlas | Penutup peribadi |
| 33.47–37.87s | Live product footage 615.00–619.40s; no new voice | brand-cta | Brand closing dan CTA |

Warm cinematic grade, natural skin, restrained transitions, original ambient score, and CTA Tekan beg Kuning. Customer face, voice and setting are retained. The history includes his own “20…25 years” correction. His continued dietary control is retained. The uncertain sentence between the two closing excerpts is omitted. No medical-result visuals, unverified rating or new efficacy claim is added.

B-roll visual pada 16.20–20.83s menggunakan sumber 615.00–619.63s, sementara suara pelanggan kekal dari 24.00–28.62s. Endcard menggunakan B-roll 615.00–619.40s, tanpa dialog baharu. Crop 640×360 pada x580,y600 mengekalkan keseluruhan kotak dan tangan sepanjang gerakan sebenar.
