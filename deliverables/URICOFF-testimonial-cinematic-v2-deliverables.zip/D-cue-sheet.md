# Cinematic Storytelling — motion, transitions and SFX

| Time | Type | Cue |
|---|---|---|
| 0.000s | Motion | hook-bonus: restrained push-in 105–109%; Montserrat phrase captions with 100–103–100% micro-scale |
| 0.030s | SFX | impact |
| 0.080s | Typography | Authentic headline Satu bonus bagi saya; 76px Montserrat, slide-up 12px and fade |
| 0.220s | Typography | Champagne underline reveals over 380ms |
| 2.800s | Motion | latar-pengalaman: restrained push-in 105–108%; Montserrat phrase captions with 100–103–100% micro-scale |
| 2.860s | SFX | click |
| 2.860s | Typography | Lower third Pengalaman Pelanggan; no unverified name |
| 8.233s | Motion | kesukaran-dulu: restrained push-in 106–110%; Montserrat phrase captions with 100–103–100% micro-scale |
| 16.200s | Motion | jumpa-produk: restrained push-in 100–102%; Montserrat phrase captions with 100–103–100% micro-scale; live B-roll from source 615s, 640x360 crop preserves whole carton |
| 16.200s | Transition | 0.20-second dissolve; live original packaging footage maintains aspect ratio; 0.20s dissolve |
| 16.220s | SFX | air |
| 16.280s | Typography | Original live product B-roll from 615s; source voice remains from 24s |
| 20.833s | Motion | pengalaman-sendiri: restrained push-in 106–110%; Montserrat phrase captions with 100–103–100% micro-scale |
| 20.833s | Transition | 0.20-second dissolve from product insert back to the original customer |
| 20.893s | Typography | Attributed quote Bagi saya ni, preserving subjective context |
| 23.433s | Motion | pemakanan: restrained push-in 105–108%; Montserrat phrase captions with 100–103–100% micro-scale |
| 23.433s | Typography | Pemakanan tetap dijaga context label |
| 30.233s | Motion | jujur: restrained push-in 105–107%; Montserrat phrase captions with 100–103–100% micro-scale |
| 31.767s | Motion | ikhlas: restrained push-in 110–112%; Montserrat phrase captions with 100–103–100% micro-scale |
| 31.817s | Typography | Actual closing quote Betul-betul ikhlas |
| 33.467s | Motion | brand-cta: restrained push-in 100–102%; Montserrat phrase captions with 100–103–100% micro-scale; live B-roll from source 615s, 640x360 crop preserves whole carton |
| 33.467s | Transition | 0.20-second dissolve; live original packaging footage maintains aspect ratio; 0.20s dissolve |
| 33.487s | SFX | air |
| 33.587s | Typography | Ivory brand closing typography |
| 33.717s | SFX | shimmer |
| 33.847s | Typography | CTA Tekan beg Kuning; yellow shopping-bag icon and charcoal button |
| 33.927s | Typography | Down arrow eases by 10px; no aggressive flash |
